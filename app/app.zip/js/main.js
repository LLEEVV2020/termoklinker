"use strict";

var g = 25;